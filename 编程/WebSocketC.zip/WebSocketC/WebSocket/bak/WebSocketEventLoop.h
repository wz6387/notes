#ifndef _WEB_SOCKET_EVENT_LOOP_H_
#define _WEB_SOCKET_EVENT_LOOP_H_
#include <memory>
#include <thread>
#include <mutex>
#include <vector>
#include "event.h"
#include "Callbacks.h"
#include "TimerId.h"

#ifdef __DLL_EXPORTS__
#define DLLAPI  __declspec(dllexport)
#else
#define DLLAPI __declspec(dllimport)
#endif

class TimerQueue;
class DLLAPI WebSocketEventLoop
{
	struct EventFifo
	{
		struct event event;
		evutil_socket_t sfd;
		evutil_socket_t cfd;
	};
public:
	typedef std::function<void()> Functor;

	WebSocketEventLoop();
	~WebSocketEventLoop();
	void startLoop();
	void stopLoop();
	TimeId runAfter(TimerCallback cb, int delay);
	void cancel(TimeId timerId);
	event_base* getBase() const { return base_;	}
	void runInLoop(Functor cb);
	bool isInLoopThread() const { return threadId_ == std::this_thread::get_id(); }
private:
	int notifyEventInit();
	void notifyEventDestory();
	void doPendingFunctors();
	static void do_accept_cb(evutil_socket_t listener, short event, void *arg);
	static void do_read_cb(evutil_socket_t listener, short event, void *arg);
	void quit();

	event_base *base_;
	std::thread* thread_;
	std::thread::id threadId_;
	std::unique_ptr<TimerQueue> timerqueue_;
	EventFifo fifo_;
	std::mutex mutex_;
	std::vector<Functor> pendingFunctors_;
};

#endif
