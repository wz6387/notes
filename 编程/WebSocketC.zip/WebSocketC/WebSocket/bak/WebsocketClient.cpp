#include "WebsocketClient.h"
#include <map>
#include <sstream>
#include <chrono>
#include "base64.h"
#include "SHA1.h"
#include "WebSocketEventLoop.h"
#include "WebSocketConnection.h"

//websocket��ϰ���󲻵ó���4MB(��ֹ�ڴ汬ը)
#define MAX_WS_PACKET (4 * 1024 * 1024)

WebSocketClient::WebSocketClient(WebSocketEventLoop* loop)
	: loop_(loop)
	, port_(0)
	, connection_(new WebSocketConnection(loop))
	, connectionCallback_(defaultConnectionCallback)
	, closeCallback_(defaultCloseCallback)
	, messageCallback_(defaultMessageCallback)
	, state_(kDisconnected)
	, threadStart_(false)
	, thread_(NULL)
	, retry_(false)
	
{
	connection_->setConnectionCallback(std::bind(&WebSocketClient::onConnect, this, _1));
	connection_->setCloseCallback(std::bind(&WebSocketClient::onClose, this, _1));
	connection_->setMessageCallback(std::bind(&WebSocketClient::onMessage, this, _1, _2));

}

WebSocketClient::~WebSocketClient()
{

}

void WebSocketClient::connect(const std::string& hostname, int port, const std::string& uri)
{
	host_ = hostname;
	port_ = port;
	uri_ = uri; 
	connection_->connect(hostname, port);
}

void WebSocketClient::disconnect()
{
	retry_ = false;
	removeConnection();
}

void WebSocketClient::onConnect(const WebSocketConnectionPtr& conn)
{
	setState(kHandshaking);
	handshake();
}

void WebSocketClient::onMessage(const WebSocketConnectionPtr& conn, const std::string& msg)
{
	if (state_ == kHandshaking) {
		if (validateHandshake(msg)) {
			newConnection(conn);
		} else {
			removeConnection();
		}
	} else if (state_ == kHandshaked) {
		WebsocketSplitter::decode((uint8_t*)msg.c_str(), msg.size());
	}
}

void WebSocketClient::onClose(const WebSocketConnectionPtr& conn)
{
	removeConnection();
	closeCallback_(conn);
}

std::string WebSocketClient::generateKey(const std::string& key)
{
	//sha-1
	std::string sha1_encode = SHA1::encode_bin("258EAFA5-E914-47DA-95CA-C5AB0DC85B11");

	//base64 encode
	return base64_encode((const uint8_t*)sha1_encode.c_str(), sha1_encode.size());
}

void WebSocketClient::handshake()
{
	// ����Ϊ handshaking�� �Ƚ��������ķ��أ���֤֮�󣬵���Ϊhandshaked
	// ��װhandshake���󣬲����Է�������
	std::string reqStr = "GET ";
	if (uri_.length() > 0) {
		if (uri_[0] != '/') {
			uri_ = "/" + uri_;
		}
	} else {
		uri_ = "/";
	}

	reqStr += uri_;

	std::string key = "key_1";
	reqStr += " HTTP/1.1\r\n";
	reqStr.append("Host: " + host_ + "\r\n");
	reqStr.append("Origin: http://www.example.com/ws \r\n");
	reqStr.append("Upgrade: websocket\r\n");
	reqStr.append("Connection: upgrade\r\n");
	reqStr.append("Sec-WebSocket-Key: " + generateKey(key) + "\r\n");
	reqStr.append("Sec-WebSocket-Version: 13\r\n\r\n");

	connection_->send(reqStr);
}

bool WebSocketClient::validateHandshake(const std::string& msg)
{
	std::string handsharkMsg;
	handsharkMsg.append(msg);
	std::string tag = "\r\n\r\n";
	int pos = handsharkMsg.find(tag);
	if (pos == std::string::npos) {
		return false;
	}
	std::string buf = handsharkMsg.substr(0, pos + tag.length());
	handsharkMsg = handsharkMsg.substr(pos + tag.length());

	std::map<std::string, std::string> headerMap;
	std::istringstream s(buf);
	std::string request;

	std::getline(s, request);
	if (request[request.size() - 1] == '\r') {
		request.erase(request.end() - 1);
	} else {
		return false;
	}

	std::string header;
	std::string::size_type end;
	while (std::getline(s, header) && header != "\r") {
		if (header[header.size() - 1] != '\r') {
			continue; //end
		} else {
			header.erase(header.end() - 1); //remove last char
		}

		end = header.find(": ", 0);
		if (end != std::string::npos) {
			std::string key = header.substr(0, end);
			std::string value = header.substr(end + 2);
			headerMap[key] = value;
		}
	}

	auto iter = headerMap.find("Sec-WebSocket-Accept");
	if (headerMap.end() == iter) {
		return false;
	} else {
		return true;
	}
}

void WebSocketClient::pong()
{
	WebSocketHeader header;
	header.m_fin = true;
	header.m_reserved = 0;
	header.m_opcode = PONG;
	header.m_mask_flag = true;
	WebsocketSplitter::encode(header, NULL, 0);
}

void WebSocketClient::ping()
{
	WebSocketHeader header;
	header.m_fin = true;
	header.m_reserved = 0;
	header.m_opcode = PING;
	header.m_mask_flag = true;
	WebsocketSplitter::encode(header, NULL, 0);
}

void WebSocketClient::startPingThread()
{
	if (thread_ == NULL) {
		threadStart_ = true;
		thread_ = new std::thread([this]() {
			while (threadStart_) {
				if (state_ == kHandshaked) {
					for (auto i = 0; i < 20; ++i) {
						std::this_thread::sleep_for(std::chrono::seconds(1));
						if (!threadStart_) {
							return;
						}
					}
					printf("send ping\n");
					ping();
				}
			}
		});
	}
}

void WebSocketClient::stopPingThread()
{
	if (thread_) {
		threadStart_ = false;
		thread_->join();
		delete thread_;
		thread_ = NULL;
	}
}

void WebSocketClient::newConnection(const WebSocketConnectionPtr& conn)
{
	setState(kHandshaked);
	//startPingThread();
	connectionCallback_(conn);
	conn->setCloseCallback(std::bind(&WebSocketClient::onClose, this, conn));
}

void WebSocketClient::removeConnection()
{
	//stopPingThread();
	setState(kDisconnected);
	connection_->disconnect();
	if (retry_) {
		//20s����һ��
		loop_->runAfter(std::bind(&WebSocketClient::connect, this, host_, port_, uri_), 20 * 1000);
	}
}

void WebSocketClient::write(const std::string& message)
{
	if (state_ == kHandshaked) {
		WebSocketHeader header;
		header.m_fin = true;
		header.m_reserved = 0;
		header.m_opcode = TEXT;
		header.m_mask_flag = true;
		WebsocketSplitter::encode(header, message.c_str(), message.size());
	}
}

void WebSocketClient::onWebSocketEncodeData(const char* buf, int len)
{
	connection_->send(std::string(buf, len));
}

void WebSocketClient::onWebSocketDecodePayload(const WebSocketHeader &header, const uint8_t *ptr, uint64_t len, uint64_t recved)
{
	m_payload_section.append((char *)ptr, len);
}

void WebSocketClient::onWebSocketDecodeComplete(const WebSocketHeader &header_in)
{
	WebSocketHeader& header = const_cast<WebSocketHeader&>(header_in);
	auto  flag = header.m_mask_flag;
	header.m_mask_flag = false;

	switch (header.m_opcode) {
	case WebSocketHeader::CLOSE: {
		removeConnection();
		break;
	}

	case WebSocketHeader::PING: {
		std::cout << "recv ping" << std::endl;
		pong();
		//header.m_opcode = WebSocketHeader::PONG;
		//WebsocketSplitter::encode(header, m_payload_section.c_str(), m_payload_section.length());
		break;
	}

	case WebSocketHeader::CONTINUATION:
	case WebSocketHeader::TEXT:
	case WebSocketHeader::BINARY: {
		if (!header.m_fin) {
			//���к�����Ƭ����, �����Ȼ������ݣ����з�Ƭ�ռ���ɲ�һ�������
			m_payload_cache.append(std::move(m_payload_section));
			if (m_payload_cache.size() < MAX_WS_PACKET) {
				//�����ڴ����������Ƭ����
				break;
			} else {
				//��Ƭ����̫����Ҫ���
				m_payload_cache.clear();
				removeConnection();
			}
		}

		//���һ����
		if (m_payload_cache.empty()) {
			messageCallback_(connection_, m_payload_section);
			//�������Ψһ����Ƭ
			//_session->onRecv(std::make_shared<WebSocketBuffer>(header._opcode, header._fin, std::move(_payload_section)));
			break;
		}

		//������ɶ����Ƭ���
		m_payload_cache.append(std::move(m_payload_section));
		messageCallback_(connection_, m_payload_cache);
		m_payload_cache.clear();
		break;
	}

	default: break;
	}
	m_payload_section.clear();
	header.m_mask_flag = flag;
}
