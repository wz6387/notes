#include "WebsocketEventLoopThreadImpl.h"
#include "WebsocketEventLoop.h"

WebsocketEventLoopThreadImpl::WebsocketEventLoopThreadImpl()
	: loop_(NULL)
	, thread_(NULL)
{

}

WebsocketEventLoopThreadImpl::~WebsocketEventLoopThreadImpl()
{
	if (loop_ && thread_) {
		loop_->quit();
		thread_->join();
		delete thread_;
		thread_ = NULL;
	}
}

WebSocketEventLoop* WebsocketEventLoopThreadImpl::startLoop()
{
	thread_ = new std::thread(&WebsocketEventLoopThreadImpl::threadFunc, this);
	std::unique_lock<std::mutex> locker(mutex_);
	cond_.wait(locker);
	return loop_;
}

void WebsocketEventLoopThreadImpl::threadFunc(void* arg)
{
	WebSocketEventLoop loop;
	WebsocketEventLoopThreadImpl* ptr = (WebsocketEventLoopThreadImpl*)arg;
	ptr->loop_ = &loop;
	ptr->cond_.notify_one();
	ptr->loop_->loop();
	ptr->loop_ = NULL;
}