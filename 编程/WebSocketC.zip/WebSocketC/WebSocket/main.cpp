#include "WebSocketEventLoop.h"
#include "WebsocketEventLoopThread.h"
#include "WebsocketClient.h"
#include <iostream>
#include <conio.h>

void connectCB(const WebSocketConnectionPtr&)
{
	std::cout << "onConnect" << std::endl;
}

void closeCB(const WebSocketConnectionPtr&)
{
	std::cout << "onClose" << std::endl;
}

void MessageCB(const WebSocketConnectionPtr& conn, const std::string& msg)
{
	std::cout << "recv:" << msg << std::endl;
}


int main(void)
{

/*
	WebSocketEventLoop base;
	std::thread thread([&]() {
		base.loop();
	});

	WebSocketClient client(&base);
	client.setConnectionCallback(connectCB);
	client.setCloseCallback(closeCB);
	client.setMessageCallback(MessageCB);
	client.connect("community.tvtsecu.com", 8890, "/ws");

	char ch;
	while (ch = _getch()) {
		if (ch == 'q') {
			break;
		}
	}
	client.disconnect();
	base.quit();
	thread.join();
*/

	WebsocketEventLoopThread loopthread;
	WebSocketEventLoop* loop = loopthread.startLoop();
	WebSocketClient client(loop);
	client.setConnectionCallback(connectCB);
	client.setCloseCallback(closeCB);
	client.setMessageCallback(MessageCB);
	client.connect("community.tvtsecu.com", 8890, "/ws");

	char ch;
	while (ch = _getch()) {
		if (ch == 'q') {
			std::cout << "quit" << std::endl;
			break;
		}
	}
	client.disconnect();
	return 0;
}