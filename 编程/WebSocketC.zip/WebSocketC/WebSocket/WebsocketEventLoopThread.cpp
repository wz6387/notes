#include "WebsocketEventLoopThread.h"
#include "WebsocketEventLoopThreadImpl.h"

WebsocketEventLoopThread::WebsocketEventLoopThread()
	: impl_(new WebsocketEventLoopThreadImpl)
{
	
}

WebsocketEventLoopThread::~WebsocketEventLoopThread()
{

}

WebSocketEventLoop* WebsocketEventLoopThread::startLoop()
{
	return impl_->startLoop();
}