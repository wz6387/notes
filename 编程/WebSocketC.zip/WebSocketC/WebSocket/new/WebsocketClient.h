#ifndef _WEB_SOCKET_CLIENT_H_
#define _WEB_SOCKET_CLIENT_H_
#include <thread>
#include "Callbacks.h"

#ifdef __DLL_EXPORTS__
#define DLLAPI  __declspec(dllexport)
#else
#define DLLAPI __declspec(dllimport)
#endif

class WebSocketEventLoop;
class WebsocketClientImpl;
class DLLAPI WebSocketClient
{
public:
	WebSocketClient(WebSocketEventLoop* loop);
	~WebSocketClient(){}
	void connect(const std::string& hostname, int port, const std::string& uri);
	void disconnect();
	void setConnectionCallback(ConnectionCallback cb);
	void setCloseCallback(CloseCallback cb);
	void setMessageCallback(MessageCallback cb);
	bool retry() const;
	void enableRetry();
	void write(const std::string& message);

private:
	std::shared_ptr<WebsocketClientImpl> impl_;	
};

#endif
