#ifndef _WEB_SOCKET_EVENT_LOOP_H_
#define _WEB_SOCKET_EVENT_LOOP_H_
#include "Callbacks.h"
#include "event.h"

#ifdef __DLL_EXPORTS__
#define DLLAPI  __declspec(dllexport)
#else
#define DLLAPI __declspec(dllimport)
#endif

class TimeId;
class WebSocketEventLoopImpl;
class DLLAPI WebSocketEventLoop
{
public:
	typedef std::function<void()> Functor;

	WebSocketEventLoop();
	~WebSocketEventLoop();
	void startLoop();
	void stopLoop();
	TimeId runAfter(TimerCallback cb, int delay);
	void cancel(TimeId timerId);
	event_base* getBase();
	void runInLoop(Functor cb);
	bool isInLoopThread() const;
private:
	std::shared_ptr<WebSocketEventLoopImpl> impl_;
};

#endif
