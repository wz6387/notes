#include "WebSocketEventLoop.h"
#include "WebsocketEventLoopImpl.h"

WebSocketEventLoop::WebSocketEventLoop()
	: impl_(new WebSocketEventLoopImpl)
{

}

WebSocketEventLoop::~WebSocketEventLoop()
{

}

void WebSocketEventLoop::startLoop()
{
	impl_->startLoop();
}

void WebSocketEventLoop::stopLoop()
{
	impl_->stopLoop();
}

TimeId WebSocketEventLoop::runAfter(TimerCallback cb, int delay)
{
	return impl_->runAfter(cb, delay);
}

void WebSocketEventLoop::cancel(TimeId timerId)
{
	impl_->cancel(timerId);
}

event_base* WebSocketEventLoop::getBase()
{
	return impl_->getBase();
}

void WebSocketEventLoop::runInLoop(Functor cb)
{
	impl_->runInLoop(cb);
}

bool WebSocketEventLoop::isInLoopThread() const
{
	return impl_->isInLoopThread();
}