#include "WebsocketEventLoopImpl.h"
#include "event2/thread.h"
#include "TimerQueue.h"
#ifdef WIN32
#include <ws2tcpip.h>
#else
#include <unistd.h>
#endif

#define WAKEUP_PORT 11215

WebSocketEventLoopImpl::WebSocketEventLoopImpl()
	: base_(NULL)
	, thread_(NULL)
	, timerqueue_(new TimerQueue())
{
#ifdef WIN32
	WORD wVersionRequested;
	WSADATA wsaData;
	wVersionRequested = MAKEWORD(2, 2);
	WSAStartup(wVersionRequested, &wsaData);
	evthread_use_windows_threads();
#else
	evthread_use_pthreads();
#endif
	base_ = event_base_new();
}

WebSocketEventLoopImpl::~WebSocketEventLoopImpl()
{
#ifdef WIN32
	WSACleanup();
#endif
}

void WebSocketEventLoopImpl::loop()
{
	notifyEventInit();
	event_base_dispatch(base_);
	event_base_free(base_);
}

void WebSocketEventLoopImpl::quit()
{
	runInLoop([=]() {
		notifyEventDestory();
		event_base_loopbreak(base_);//����Ҫ��io�̵߳���
	});
}

TimeId WebSocketEventLoopImpl::runAfter(TimerCallback cb, int delay)
{
	return timerqueue_->addTimer(cb, delay);
}

void WebSocketEventLoopImpl::cancel(TimeId timerId)
{
	timerqueue_->cancel(timerId);
}

int WebSocketEventLoopImpl::notifyEventInit()
{
	//tcp server
	evutil_socket_t listener = socket(AF_INET, SOCK_STREAM, 0);
	evutil_make_listen_socket_reuseable(listener);
	struct sockaddr_in sin;
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = htonl(0x7f000001);
	sin.sin_port = htons(WAKEUP_PORT);
	if (bind(listener, (struct sockaddr *)&sin, sizeof(sin)) < 0) {
		return -1;
	}
	if (listen(listener, 5) < 0) {
		return -1;
	}
	evutil_make_socket_nonblocking(listener);
	fifo_.sfd = listener;

	event_set(&fifo_.event, listener,
		EV_READ | EV_PERSIST, WebSocketEventLoopImpl::do_accept_cb, this);
	event_base_set(base_, &fifo_.event);
	event_add(&fifo_.event, 0);

	//tcp client
	evutil_socket_t clientfd = ::socket(AF_INET, SOCK_STREAM, 0);
	::connect(clientfd, (struct sockaddr*)&sin, sizeof(sin));
	evutil_make_socket_nonblocking(clientfd);
	fifo_.cfd = clientfd;
	return 0;
}

void WebSocketEventLoopImpl::notifyEventDestory()
{
	evutil_closesocket(fifo_.sfd);
	evutil_closesocket(fifo_.cfd);
}

void WebSocketEventLoopImpl::do_accept_cb(evutil_socket_t listener, short event, void *arg)
{
	WebSocketEventLoopImpl *ptr = (WebSocketEventLoopImpl*)arg;
	struct sockaddr_in sin;
	socklen_t slen = sizeof(sin);
	evutil_socket_t fd = accept(listener, (struct sockaddr *)&sin, &slen);
	if (fd < 0) {
		return;
	}
	evutil_make_socket_nonblocking(fd);

	struct event *ev = event_new(ptr->base_, fd, EV_READ | EV_PERSIST, WebSocketEventLoopImpl::do_read_cb, arg);
	event_add(ev, NULL);
}

void WebSocketEventLoopImpl::do_read_cb(evutil_socket_t listener, short event, void *arg)
{
	WebSocketEventLoopImpl *ptr = (WebSocketEventLoopImpl*)arg;
	char msg[512] = { 0 };
#ifdef WIN32
	::recv(listener, msg, sizeof(msg), 0);
#else
	::read(listener, msg, sizeof(msg));
#endif
	ptr->doPendingFunctors();
}

void WebSocketEventLoopImpl::runInLoop(Functor cb)
{
	if (isInLoopThread()) {
		cb();
	}
	else {
		{
			std::lock_guard<std::mutex> lock(mutex_);
			pendingFunctors_.push_back(std::move(cb));
		}
#ifdef WIN32
		::send(fifo_.cfd, "c", 1, 0);
#else
		::write(fifo_.cfd, "c", 1);
#endif
	}
}

void WebSocketEventLoopImpl::doPendingFunctors()
{
	std::vector<Functor> functors;

	{
		std::lock_guard<std::mutex> lock(mutex_);
		functors.swap(pendingFunctors_);
	}

	for (const Functor& functor : functors)
	{
		functor();
	}
}